import 'package:flutter_test/flutter_test.dart';
import 'package:taiz_express/utils/validators.dart';

void main() {
  group('Yemeni phone validation', () {
    test('accepts local and international formats', () {
      expect(Validators.isValidYemeniPhone('771234567'), isTrue);
      expect(Validators.isValidYemeniPhone('+967771234567'), isTrue);
      expect(Validators.isValidYemeniPhone('00967771234567'), isTrue);
    });

    test('rejects invalid numbers', () {
      expect(Validators.isValidYemeniPhone('77123456'), isFalse);
      expect(Validators.isValidYemeniPhone('991234567'), isFalse);
      expect(Validators.isValidYemeniPhone(''), isFalse);
    });
  });
}
