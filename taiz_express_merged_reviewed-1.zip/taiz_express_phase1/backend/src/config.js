import 'dotenv/config';

function required(name) {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`متغير البيئة ${name} مطلوب.`);
  return value;
}

const jwtSecret = required('JWT_SECRET');
if (Buffer.byteLength(jwtSecret, 'utf8') < 32) {
  throw new Error('JWT_SECRET يجب أن يكون 32 بايت على الأقل.');
}

export const config = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT || 4000),
  databaseUrl: required('DATABASE_URL'),
  jwtSecret,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '12h',
  corsOrigins: (process.env.CORS_ORIGINS || 'http://localhost:5500').split(',').map((x) => x.trim()).filter(Boolean),
  deliveryBaseFee: Number(process.env.DELIVERY_BASE_FEE_YER ?? 500),
  deliveryPerKmFee: Number(process.env.DELIVERY_PER_KM_FEE_YER ?? 100),
};

if (!Number.isInteger(config.port) || config.port < 1 || config.port > 65535) throw new Error('PORT غير صالح.');
if (![config.deliveryBaseFee, config.deliveryPerKmFee].every((n) => Number.isInteger(n) && n >= 0)) {
  throw new Error('رسوم التوصيل يجب أن تكون أعداداً صحيحة موجبة أو صفراً.');
}
