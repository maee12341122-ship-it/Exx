(() => {
  let token = '';
  let apiBase = 'http://localhost:4000/api';
  let couriers = [];
  const $ = (id) => document.getElementById(id);
  const loginPanel = $('loginPanel');
  const dashboard = $('dashboard');

  async function api(path, options = {}) {
    const response = await fetch(`${apiBase}${path}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) },
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `خطأ HTTP ${response.status}`);
    return payload;
  }

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[c]);
  const money = (value) => `${Number(value || 0).toLocaleString('en-US')} ر.ي`;
  const statusName = (value) => ({pending:'بانتظار المراجعة',accepted:'تم القبول',preparing:'قيد التجهيز',ready:'جاهز للاستلام',assigned:'تم تعيين مندوب',picked_up:'استلمه المندوب',on_the_way:'في الطريق',delivered:'تم التسليم',cancelled:'ملغي'})[value] || value;
  const paymentName = (value) => value === 'collected' ? 'تم تحصيل النقد' : 'غير مدفوع';
  function message(text, error = false) {
    $('dashboardMessage').textContent = text;
    $('dashboardMessage').style.color = error ? '#ff9b9b' : '#e5bf72';
  }

  async function loadAll() {
    message('');
    const [orderData, courierData, restaurantData, productData] = await Promise.all([
      api('/admin/orders'), api('/admin/couriers'), api('/admin/restaurants'), api('/admin/products'),
    ]);
    couriers = courierData.couriers;
    renderOrders(orderData.orders);
    renderCouriers(couriers);
    renderRestaurants(restaurantData.restaurants);
    renderProducts(productData.products);
  }

  function renderOrders(orders) {
    $('orderCount').textContent = String(orders.length);
    $('ordersList').innerHTML = orders.length ? orders.map((o) => {
      const available = couriers.filter((c) => c.is_active && c.is_available);
      const assign = o.status === 'ready' && !o.courier_id ? `
        <select id="courier-${esc(o.id)}"><option value="">اختر المندوب</option>${available.map(c => `<option value="${esc(c.id)}">${esc(c.name)} · ${esc(c.phone || '')}</option>`).join('')}</select>
        <button class="button primary" data-action="assign" data-id="${esc(o.id)}">تعيين يدوياً</button>` : '';
      const next = ({pending:'accepted',accepted:'preparing',preparing:'ready'})[o.status];
      const change = next ? `<button class="button" data-action="status" data-status="${next}" data-id="${esc(o.id)}">${statusName(next)}</button>` : '';
      return `<article class="order-card">
        <div class="order-head"><strong>طلب #${esc(o.order_number)}</strong><span class="pill gold">${statusName(o.status)}</span></div>
        <div class="order-meta"><span>العميل: ${esc(o.customer_name)} · ${esc(o.customer_phone)}</span><span>المتجر: ${esc(o.restaurant_name)}</span><span>العنوان: ${esc(o.address_text)}</span><span>الإجمالي: <b>${money(o.total_yer)}</b></span><span>الدفع: ${paymentName(o.payment_status)}</span><span>المندوب: ${esc(o.courier_name || 'لم يُعيّن بعد')}</span></div>
        <div class="order-items">${(o.items || []).map(i => `${esc(i.product_name)} × ${esc(i.quantity)} — ${money(i.line_total_yer)}`).join('<br>')}</div>
        <div class="actions">${change}${assign}${o.status !== 'delivered' && o.status !== 'cancelled' ? `<button class="button danger" data-action="cancel" data-id="${esc(o.id)}">إلغاء الطلب</button>` : ''}</div>
      </article>`;
    }).join('') : '<p class="muted">لا توجد طلبات حتى الآن.</p>';
  }

  function renderCouriers(rows) {
    $('couriersList').innerHTML = rows.length ? rows.map(c => `<div class="mini-card"><div><strong>${esc(c.name)}</strong><small>${esc(c.username)} · ${esc(c.phone || '')}</small><br><small>${c.is_active ? (c.is_available ? 'متاح' : 'مرتبط بطلب نشط') : 'موقوف'}</small></div><button class="button ${c.is_active ? 'danger' : ''}" data-action="courier-active" data-id="${esc(c.id)}" data-active="${!c.is_active}">${c.is_active ? 'إيقاف' : 'تفعيل'}</button></div>`).join('') : '<p class="muted">لم تتم إضافة مناديب.</p>';
  }

  function renderRestaurants(rows) {
    $('restaurantSelect').innerHTML = rows.filter(r => r.is_active).map(r => `<option value="${esc(r.id)}">${esc(r.name)}</option>`).join('') || '<option value="">أضف مطعماً أولاً</option>';
  }

  function renderProducts(rows) {
    $('productsList').innerHTML = rows.length ? rows.map(p => `<div class="mini-card"><div><strong>${esc(p.name)}</strong><small>${esc(p.restaurant_name)} · ${money(p.price_yer)} · ${p.is_available ? 'متوفر' : 'غير متوفر'}</small></div><button class="button" data-action="product-availability" data-id="${esc(p.id)}" data-active="${!p.is_available}">${p.is_available ? 'إيقاف التوفر' : 'إتاحة المنتج'}</button></div>`).join('') : '<p class="muted">لا توجد منتجات مسجلة.</p>';
  }

  $('loginForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    $('loginMessage').textContent = 'جارٍ تسجيل الدخول…';
    apiBase = $('apiBase').value.trim().replace(/\/$/, '');
    try {
      const data = await api('/auth/login', { method: 'POST', body: JSON.stringify({ identifier: $('username').value.trim(), password: $('password').value }) });
      if (data.user.role !== 'admin') throw new Error('هذا الحساب ليس حساب مشرف.');
      token = data.token;
      loginPanel.classList.add('hidden');
      dashboard.classList.remove('hidden');
      $('logoutBtn').classList.remove('hidden');
      await loadAll();
    } catch (error) { $('loginMessage').textContent = error.message; }
  });

  $('logoutBtn').addEventListener('click', () => {
    token = '';
    dashboard.classList.add('hidden');
    loginPanel.classList.remove('hidden');
    $('logoutBtn').classList.add('hidden');
    $('password').value = '';
  });
  $('refreshBtn').addEventListener('click', () => loadAll().catch(e => message(e.message, true)));

  document.querySelectorAll('.tab').forEach((button) => button.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((item) => item.classList.toggle('active', item === button));
    document.querySelectorAll('.tab-content').forEach((item) => item.classList.add('hidden'));
    $(`${button.dataset.tab}Tab`).classList.remove('hidden');
  }));

  document.body.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-action]');
    if (!button) return;
    try {
      const { action, id } = button.dataset;
      if (action === 'assign') {
        const courierId = $(`courier-${id}`).value;
        if (!courierId) throw new Error('اختر مندوباً أولاً.');
        await api(`/admin/orders/${id}/assign`, { method: 'PATCH', body: JSON.stringify({ courierId }) });
      } else if (action === 'status' || action === 'cancel') {
        const status = action === 'cancel' ? 'cancelled' : button.dataset.status;
        await api(`/admin/orders/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });
      } else if (action === 'courier-active') {
        await api(`/admin/couriers/${id}/active`, { method: 'PATCH', body: JSON.stringify({ isActive: button.dataset.active === 'true' }) });
      } else if (action === 'product-availability') {
        await api(`/admin/products/${id}`, { method: 'PATCH', body: JSON.stringify({ isAvailable: button.dataset.active === 'true' }) });
      }
      await loadAll();
    } catch (error) { message(error.message, true); }
  });

  $('restaurantForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const lat = form.get('latitude'); const lng = form.get('longitude');
    const payload = { name: form.get('name'), address: form.get('address'), imageUrl: form.get('imageUrl') || '' };
    if (lat !== '' && lng !== '') { payload.latitude = Number(lat); payload.longitude = Number(lng); }
    try { await api('/admin/restaurants', { method: 'POST', body: JSON.stringify(payload) }); event.currentTarget.reset(); await loadAll(); message('تم حفظ المطعم أو المتجر.'); }
    catch (error) { message(error.message, true); }
  });

  $('productForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const payload = { restaurantId: form.get('restaurantId'), name: form.get('name'), category: form.get('category'), priceYer: Number(form.get('priceYer')), unit: form.get('unit'), isAvailable: form.get('isAvailable') === 'on' };
    try { await api('/admin/products', { method: 'POST', body: JSON.stringify(payload) }); event.currentTarget.reset(); await loadAll(); message('تم حفظ المنتج.'); }
    catch (error) { message(error.message, true); }
  });

  $('courierForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(['name','username','phone','password'].map(k => [k, form.get(k)]));
    try { await api('/admin/couriers', { method: 'POST', body: JSON.stringify(payload) }); event.currentTarget.reset(); await loadAll(); message('تم إنشاء حساب المندوب.'); }
    catch (error) { message(error.message, true); }
  });
})();
