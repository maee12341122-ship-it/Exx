import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'providers/app_state.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    ChangeNotifierProvider<AppState>(
      create: (_) => AppState()..loadLocalData(),
      child: const TaizExpressApp(),
    ),
  );
}
