import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/product_model.dart';
import '../providers/app_state.dart';
import '../utils/constants.dart';
import '../widgets/empty_state.dart';
import '../widgets/product_card.dart';
import 'admin_login_screen.dart';
import 'custom_order_widget.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback? onOpenDrawer;
  const HomeScreen({super.key, this.onOpenDrawer});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String _selectedCategory = ProductCategories.restaurants;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _showAdminPreview() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AdminLoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final searchResults = state.searchProducts(_searchQuery);
    final visibleProducts = _searchQuery.isNotEmpty
        ? searchResults
        : state.productsByCategory(_selectedCategory);

    return Scaffold(
      appBar: AppBar(
        leading: widget.onOpenDrawer == null
            ? null
            : IconButton(icon: const Icon(Icons.menu), onPressed: widget.onOpenDrawer),
        title: const Text('تعز إكسبرس'),
        actions: [
          IconButton(
            icon: const Icon(Icons.admin_panel_settings, color: AppConstants.gold),
            tooltip: 'وضع معاينة الإدارة المحلي',
            onPressed: _showAdminPreview,
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(12, 10, 12, 2),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.centerRight,
                end: Alignment.centerLeft,
                colors: [Color(0xFFFFC107), Color(0xFFFFA000)],
              ),
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: AppConstants.gold.withOpacity(0.18),
                  blurRadius: 14,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'كل احتياجاتك توصلك',
                        style: TextStyle(
                          color: Color(0xFF241900),
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      SizedBox(height: 5),
                      Text(
                        'اطلب من متاجر ومطاعم تعز بسهولة',
                        style: TextStyle(
                          color: Color(0xFF493500),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                const CircleAvatar(
                  radius: 27,
                  backgroundColor: Color(0x33FFFFFF),
                  child: Icon(Icons.delivery_dining, size: 34, color: Color(0xFF241900)),
                ),
              ],
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
            color: state.isWorkingHours ? Colors.green.shade800 : Colors.red.shade800,
            child: Text(
              state.isWorkingHours
                  ? 'التطبيق مفتوح حالياً • الدوام ${state.workStartHour}:00 - ${state.workEndHour}:00'
                  : 'التطبيق مغلق حالياً • الدوام ${state.workStartHour}:00 - ${state.workEndHour}:00',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: TextField(
              controller: _searchController,
              onChanged: (value) => setState(() => _searchQuery = value.trim()),
              decoration: InputDecoration(
                hintText: 'ابحث عن مطعم أو وجبة أو منتج أو متجر...',
                prefixIcon: const Icon(Icons.search, color: AppConstants.gold),
                suffixIcon: _searchQuery.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchQuery = '');
                        },
                        icon: const Icon(Icons.close),
                      ),
                filled: true,
                fillColor: Theme.of(context).colorScheme.surface,
              ),
            ),
          ),
          if (_searchQuery.isEmpty)
            SizedBox(
              height: 48,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                children: [
                  _categoryTab(ProductCategories.restaurants, 'المطاعم', Icons.restaurant),
                  _categoryTab(ProductCategories.groceries, 'البقالات', Icons.local_grocery_store),
                  _categoryTab(ProductCategories.produce, 'خضار وفواكه', Icons.eco),
                  _categoryTab(ProductCategories.pharmacy, 'صيدلية آمنة', Icons.local_pharmacy),
                  _categoryTab(ProductCategories.custom, 'طلبات أخرى', Icons.edit_note),
                ],
              ),
            ),
          const Divider(color: AppConstants.gold, height: 12),
          Expanded(
            child: _searchQuery.isNotEmpty
                ? _buildSearchResults(visibleProducts)
                : _selectedCategory == ProductCategories.custom
                    ? const CustomOrderWidget()
                    : _buildCategoryProducts(visibleProducts),
          ),
        ],
      ),
    );
  }

  Widget _categoryTab(String category, String label, IconData icon) {
    final isSelected = _selectedCategory == category;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3),
      child: ChoiceChip(
        selected: isSelected,
        onSelected: (_) => setState(() => _selectedCategory = category),
        avatar: Icon(icon, size: 17, color: isSelected ? Colors.black : AppConstants.gold),
        label: Text(label),
        selectedColor: AppConstants.gold,
        labelStyle: TextStyle(color: isSelected ? Colors.black : null, fontWeight: FontWeight.bold, fontSize: 12),
      ),
    );
  }

  Widget _buildSearchResults(List<ProductModel> products) {
    if (products.isEmpty) return const EmptyState(message: 'لا توجد نتائج مطابقة لبحثك', icon: Icons.search_off);
    return ListView.builder(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      itemCount: products.length,
      itemBuilder: (context, index) => ProductCard(
        product: products[index],
        onAdd: () => _addToCart(products[index]),
      ),
    );
  }

  Widget _buildCategoryProducts(List<ProductModel> products) {
    if (products.isEmpty) return const EmptyState(message: 'لا توجد منتجات في هذا القسم حالياً');
    if (_selectedCategory == ProductCategories.restaurants) {
      final grouped = <String, List<ProductModel>>{};
      for (final product in products) {
        grouped.putIfAbsent(product.storeName, () => []).add(product);
      }
      return ListView(
        children: grouped.entries.map((entry) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
                child: Text(entry.key,
                    style: const TextStyle(color: AppConstants.gold, fontWeight: FontWeight.bold, fontSize: 17)),
              ),
              ...entry.value.map((product) => ProductCard(product: product, onAdd: () => _addToCart(product))),
            ],
          );
        }).toList(),
      );
    }
    return ListView.builder(
      itemCount: products.length,
      itemBuilder: (context, index) => ProductCard(
        product: products[index],
        onAdd: () => _addToCart(products[index]),
      ),
    );
  }

  void _addToCart(ProductModel product) {
    context.read<AppState>().addProductToCart(product);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('تمت إضافة ${product.name} إلى السلة')),
    );
  }
}
