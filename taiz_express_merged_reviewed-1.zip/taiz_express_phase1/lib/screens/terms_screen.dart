import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../providers/app_state.dart';
import '../utils/constants.dart';
import 'main_shell.dart';
import 'register_screen.dart';

class TermsScreen extends StatefulWidget {
  const TermsScreen({super.key});

  @override
  State<TermsScreen> createState() => _TermsScreenState();
}

class _TermsScreenState extends State<TermsScreen> {
  bool _accepted = false;
  bool _redirected = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _redirected) return;
      final state = context.read<AppState>();
      if (!state.isReady || !state.acceptedTerms) return;
      _redirected = true;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => state.user == null ? const RegisterScreen() : const MainShell(),
        ),
      );
    });
  }

  Future<void> _confirmExit() async {
    final shouldExit = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('تأكيد الخروج'),
            content: const Text('هل أنت متأكد من الخروج من تطبيق تعز إكسبرس؟'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: Colors.red),
                onPressed: () => Navigator.pop(dialogContext, true),
                child: const Text('نعم، خروج'),
              ),
            ],
          ),
        ) ??
        false;
    if (shouldExit) await SystemNavigator.pop();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    if (!state.isReady) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _confirmExit();
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('الشروط والأحكام')),
        body: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppConstants.gold.withOpacity(0.35)),
                  ),
                  child: const SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('مرحباً بك في خدمة تعز إكسبرس للتوصيل',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppConstants.gold)),
                        SizedBox(height: 12),
                        Text(
                          '1. أدخل بيانات تواصل صحيحة وعنواناً واضحاً لتسهيل التسليم.\n\n'
                          '2. يتحمل العميل قيمة المنتجات ورسوم التوصيل الموضحة قبل إرسال الطلب.\n\n'
                          '3. الأسعار والمنتجات المعروضة في هذه النسخة بيانات تجريبية إلى أن تُربط بقاعدة بيانات المتاجر.\n\n'
                          '4. لا يُعد اختيار المحفظة في هذه النسخة عملية تحويل مالي؛ لا تحوّل أي مبلغ قبل اعتماد بيانات الدفع الرسمية.\n\n'
                          '5. تحتفظ الإدارة بحق مراجعة الطلب وتأكيد توفر المنتجات ورسوم التوصيل قبل التنفيذ.',
                          style: TextStyle(height: 1.8),
                        ),
                        SizedBox(height: 16),
                        Text('سياسة الخصوصية المختصرة',
                            style: TextStyle(fontWeight: FontWeight.bold, color: AppConstants.gold)),
                        SizedBox(height: 6),
                        Text(
                          'تُحفظ بيانات التجربة على هذا الجهاز فقط. لا توجد حالياً مزامنة سحابية أو حسابات موثقة بين الأجهزة. '
                          'لا تستخدم بيانات حقيقية حساسة في هذه النسخة قبل تجهيز الخادم وقواعد الأمان.',
                          style: TextStyle(height: 1.8),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              CheckboxListTile(
                value: _accepted,
                onChanged: (value) => setState(() => _accepted = value ?? false),
                activeColor: AppConstants.gold,
                title: const Text('أوافق على الشروط والأحكام وسياسة الخصوصية'),
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton(
                  onPressed: !_accepted
                      ? null
                      : () {
                          context.read<AppState>().acceptTerms();
                          Navigator.of(context).pushReplacement(
                            MaterialPageRoute(builder: (_) => const RegisterScreen()),
                          );
                        },
                  child: const Text('موافقة والمتابعة', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
