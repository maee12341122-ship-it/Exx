import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/address_model.dart';
import '../providers/app_state.dart';
import '../utils/constants.dart';
import '../widgets/empty_state.dart';

class CartScreen extends StatefulWidget {
  final VoidCallback? onOpenDrawer;
  const CartScreen({super.key, this.onOpenDrawer});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final user = state.user;
    final address = user?.defaultAddress;

    return Scaffold(
      appBar: AppBar(
        leading: widget.onOpenDrawer == null ? null : IconButton(icon: const Icon(Icons.menu), onPressed: widget.onOpenDrawer),
        title: const Text('سلة المشتريات'),
      ),
      body: state.cart.isEmpty
          ? const EmptyState(message: 'السلة فارغة حالياً', icon: Icons.shopping_cart_outlined)
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.only(top: 6),
                    itemCount: state.cart.length,
                    itemBuilder: (context, index) {
                      final item = state.cart[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                        color: Theme.of(context).colorScheme.surface,
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Row(
                            children: [
                              const Icon(Icons.shopping_bag_outlined, color: AppConstants.gold, size: 30),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                                    Text('${item.unitPrice} ر.ي / ${item.unit}  •  الإجمالي ${item.lineTotal} ر.ي',
                                        style: const TextStyle(color: Colors.greenAccent, fontSize: 12)),
                                    Row(
                                      children: [
                                        IconButton(
                                          visualDensity: VisualDensity.compact,
                                          onPressed: () => context.read<AppState>().changeCartQuantity(item.productId, -1),
                                          icon: const Icon(Icons.remove_circle_outline),
                                        ),
                                        Text('${item.quantity}', style: const TextStyle(fontWeight: FontWeight.bold)),
                                        IconButton(
                                          visualDensity: VisualDensity.compact,
                                          onPressed: () => context.read<AppState>().changeCartQuantity(item.productId, 1),
                                          icon: const Icon(Icons.add_circle_outline),
                                        ),
                                        const Spacer(),
                                        IconButton(
                                          tooltip: 'حذف المنتج',
                                          onPressed: () => context.read<AppState>().removeCartItem(item.productId),
                                          icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                _checkoutPanel(state, address),
              ],
            ),
    );
  }

  Widget _checkoutPanel(AppState state, AddressModel? address) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              const Icon(Icons.location_on_outlined, color: AppConstants.gold),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  address == null ? 'لا يوجد عنوان محفوظ' : '${address.area} - ${address.details}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          if (address == null)
            const Padding(
              padding: EdgeInsets.only(top: 6),
              child: Text('أضف عنواناً من صفحة حسابي قبل إرسال الطلب.', style: TextStyle(color: Colors.redAccent, fontSize: 12)),
            ),
          const SizedBox(height: 12),
          const Text('طريقة الدفع', style: TextStyle(color: AppConstants.gold, fontWeight: FontWeight.bold)),
          const ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.payments_outlined),
            title: Text('الدفع نقداً عند الاستلام'),
            subtitle: Text('تدفع قيمة الطلب للمندوب بعد وصوله إليك.'),
          ),
          const SizedBox(height: 12),
          _summaryRow('مجموع المنتجات', state.cartSubtotal),
          _summaryRow('رسوم التوصيل التقديرية', state.deliveryFee),
          const Divider(),
          _summaryRow('الإجمالي', state.cartTotal, strong: true),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => context.read<AppState>().clearCart(),
                  child: const Text('إفراغ السلة'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  onPressed: address == null ? null : () => _confirmOrder(state),
                  child: const Text('تنفيذ الطلب'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _summaryRow(String label, int amount, {bool strong = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontWeight: strong ? FontWeight.bold : FontWeight.normal)),
          Text('$amount ر.ي', style: TextStyle(color: strong ? AppConstants.gold : null, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Future<void> _confirmOrder(AppState state) async {
    final accepted = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('مراجعة الطلب'),
            content: Text(
              'الإجمالي ${state.cartSubtotal + state.deliveryFee} ريال يمني.\n'
              'الدفع نقداً عند الاستلام.\n\n'
              'سيُحفظ الطلب على هذا الجهاز فقط في هذه المرحلة.',
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('رجوع')),
              FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('تأكيد محلي')),
            ],
          ),
        ) ??
        false;
    if (!accepted || !mounted) return;
    try {
      final order = context.read<AppState>().placeOrder(
            deliveryFee: state.deliveryFee,
          );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('حُفظ الطلب ${order.id} على هذا الجهاز.')),
      );
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString().replaceFirst('Bad state: ', ''))),
      );
    }
  }
}
