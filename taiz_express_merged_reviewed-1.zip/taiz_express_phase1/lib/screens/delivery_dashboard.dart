import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/order_model.dart';
import '../providers/app_state.dart';
import '../utils/constants.dart';
import '../widgets/empty_state.dart';

class DeliveryDashboard extends StatelessWidget {
  final String deliveryId;
  const DeliveryDashboard({super.key, required this.deliveryId});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final courier = state.couriers.where((item) => item.id == deliveryId).firstOrNull;
    if (courier == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('حساب المندوب')),
        body: const EmptyState(message: 'حساب المندوب غير متاح أو تم تعطيله.'),
      );
    }

    final assignedOrders = state.ordersForCourier(deliveryId);
    final activeOrder = assignedOrders.where((order) =>
        order.status != OrderStatuses.delivered && order.status != OrderStatuses.cancelled).firstOrNull;

    return Scaffold(
      appBar: AppBar(
        title: Text('حساب المندوب • ${courier.name}'),
        actions: [IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.logout), tooltip: 'خروج')],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: Theme.of(context).colorScheme.surface,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Icon(courier.isAvailable ? Icons.check_circle : Icons.pause_circle,
                      size: 62, color: courier.isAvailable ? Colors.green : Colors.red),
                  const SizedBox(height: 8),
                  Text(courier.isAvailable ? 'متاح لاستلام الطلبات' : 'غير متاح حالياً',
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                  Text('الطلبات المكتملة اليوم: ${courier.completedToday}', style: const TextStyle(color: Colors.grey)),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('إتاحة استقبال الطلبات'),
                    value: courier.isAvailable,
                    onChanged: courier.currentOrderId != null
                        ? null
                        : (value) => context.read<AppState>().setCourierAvailability(deliveryId, value),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('الطلب الحالي', style: TextStyle(fontSize: 17, color: AppConstants.gold, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (activeOrder == null)
            const EmptyState(message: 'لا يوجد طلب مسند إليك حالياً', icon: Icons.inbox_outlined)
          else
            _ActiveDeliveryOrder(order: activeOrder),
          const SizedBox(height: 20),
          const Text('سجل طلباتك', style: TextStyle(fontSize: 17, color: AppConstants.gold, fontWeight: FontWeight.bold)),
          ...assignedOrders.map((order) => ListTile(
                title: Text('طلب ${order.id}'),
                subtitle: Text('${OrderStatuses.label(order.status)} • ${order.total} ر.ي'),
              )),
          const SizedBox(height: 12),
          const Text(
            'هذه لوحة مندوب محلية للتجربة فقط. لا يتم إرسال الموقع أو الإشعارات إلى العميل أو المشرف عبر الإنترنت في هذه المرحلة.',
            style: TextStyle(color: Colors.grey, fontSize: 11),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _ActiveDeliveryOrder extends StatelessWidget {
  final OrderModel order;
  const _ActiveDeliveryOrder({required this.order});

  @override
  Widget build(BuildContext context) {
    String nextStatus;
    String actionLabel;
    switch (order.status) {
      case OrderStatuses.assigned:
        nextStatus = OrderStatuses.pickedUp;
        actionLabel = 'تأكيد استلام الطلب من المتجر';
        break;
      case OrderStatuses.pickedUp:
        nextStatus = OrderStatuses.onTheWay;
        actionLabel = 'بدأت التوصيل إلى العميل';
        break;
      case OrderStatuses.onTheWay:
        nextStatus = OrderStatuses.delivered;
        actionLabel = 'تأكيد تسليم الطلب';
        break;
      default:
        nextStatus = '';
        actionLabel = '';
    }

    return Card(
      color: Theme.of(context).colorScheme.surface,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('طلب ${order.id}', style: const TextStyle(color: AppConstants.gold, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('العميل: ${order.customerName}'),
            Text('الهاتف: ${order.customerPhone}'),
            Text('العنوان: ${order.address.area} - ${order.address.details}'),
            if (order.address.hasCoordinates)
              Text('الموقع: ${order.address.latitude}, ${order.address.longitude}', style: const TextStyle(color: Colors.grey, fontSize: 11)),
            const Divider(),
            ...order.items.map((item) => Text('${item.name} × ${item.quantity}')),
            const SizedBox(height: 8),
            Text('حالة الطلب: ${OrderStatuses.label(order.status)}'),
            if (order.status == OrderStatuses.onTheWay && order.paymentStatus == PaymentStatuses.unpaid)
              const Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: Text('اجمع قيمة الطلب نقداً من العميل ثم أكّد التحصيل والتسليم.',
                    style: TextStyle(color: Colors.orangeAccent, fontWeight: FontWeight.bold)),
              ),
            if (nextStatus.isNotEmpty)
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: order.status == OrderStatuses.onTheWay
                      ? () => _confirmCashAndDelivery(context)
                      : () => context.read<AppState>().updateOrderStatus(order.id, nextStatus),
                  child: Text(order.status == OrderStatuses.onTheWay && order.paymentStatus == PaymentStatuses.unpaid
                      ? 'تأكيد استلام النقد وتسليم الطلب'
                      : actionLabel),
                ),
              ),
          ],
        ),
      ),
    );
  }
  Future<void> _confirmCashAndDelivery(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تأكيد تحصيل المبلغ'),
        content: Text('هل استلمت من العميل مبلغ ${order.total} ريال يمني نقداً؟ لا تؤكد إلا بعد استلام المبلغ فعلياً.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('رجوع')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('نعم، استلمت المبلغ')),
        ],
      ),
    ) ?? false;
    if (!confirmed || !context.mounted) return;
    final state = context.read<AppState>();
    state.updatePaymentStatus(order.id, PaymentStatuses.paid);
    state.updateOrderStatus(order.id, OrderStatuses.delivered);
  }

}

extension _DeliveryFirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
