import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/address_model.dart';
import '../models/cart_item_model.dart';
import '../models/delivery_model.dart';
import '../models/order_model.dart';
import '../models/product_model.dart';
import '../models/user_model.dart';
import '../utils/constants.dart';
import '../utils/validators.dart';

class AppState extends ChangeNotifier {
  final List<CartItemModel> _cart = [];
  final List<OrderModel> _orders = [];
  final List<DeliveryModel> _couriers = [];
  final List<ProductModel> _products = _demoProducts();

  UserModel? _user;
  ThemeMode _themeMode = ThemeMode.dark;
  bool _acceptedTerms = false;
  int _workStartHour = 11;
  int _workEndHour = 22;
  int _deliveryFee = 500;
  bool _isReady = false;

  List<CartItemModel> get cart => List.unmodifiable(_cart);
  List<OrderModel> get orders => List.unmodifiable(_orders);
  List<DeliveryModel> get couriers => List.unmodifiable(_couriers);
  List<ProductModel> get products => List.unmodifiable(_products);
  UserModel? get user => _user;
  ThemeMode get themeMode => _themeMode;
  bool get acceptedTerms => _acceptedTerms;
  bool get isReady => _isReady;
  int get workStartHour => _workStartHour;
  int get workEndHour => _workEndHour;
  int get deliveryFee => _deliveryFee;
  int get cartItemCount => _cart.fold(0, (sum, item) => sum + item.quantity);
  int get cartSubtotal => _cart.fold(0, (sum, item) => sum + item.lineTotal);
  int get cartTotal => cartSubtotal + _deliveryFee;

  bool get isWorkingHours {
    final now = DateTime.now();
    final start = _workStartHour.clamp(0, 23);
    final end = _workEndHour.clamp(1, 24);
    if (start == end) return true;
    if (start < end) return now.hour >= start && now.hour < end;
    return now.hour >= start || now.hour < end;
  }

  static List<ProductModel> _demoProducts() => const [
        ProductModel(
          id: 'meal-001',
          name: 'وجبة مشكل سفري',
          storeName: 'مطعم الشيباني',
          category: ProductCategories.restaurants,
          price: 3500,
          unit: 'وجبة',
          imageUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=500',
          description: 'وجبة مشكل سفري.',
        ),
        ProductModel(
          id: 'meal-002',
          name: 'مظبي لحم',
          storeName: 'مطعم الشيباني',
          category: ProductCategories.restaurants,
          price: 5000,
          unit: 'وجبة',
          imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500',
        ),
        ProductModel(
          id: 'meal-003',
          name: 'دجاج شواية مع الأرز',
          storeName: 'مطعم الشرق',
          category: ProductCategories.restaurants,
          price: 4000,
          unit: 'وجبة',
          imageUrl: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=500',
        ),
        ProductModel(
          id: 'meal-004',
          name: 'بروستد دجاج',
          storeName: 'مطعم الشرق',
          category: ProductCategories.restaurants,
          price: 3000,
          unit: 'وجبة',
          imageUrl: 'https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=500',
        ),
        ProductModel(
          id: 'grocery-001',
          name: 'حليب المراعي 1 لتر',
          storeName: 'بقالة تجريبية',
          category: ProductCategories.groceries,
          price: 1200,
          unit: 'عبوة',
          imageUrl: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?w=500',
        ),
        ProductModel(
          id: 'grocery-002',
          name: 'سكر الروضة 1 كيلو',
          storeName: 'بقالة تجريبية',
          category: ProductCategories.groceries,
          price: 900,
          unit: 'كيس',
          imageUrl: 'https://images.unsplash.com/photo-1581404169727-c1ff3608796f?w=500',
        ),
        ProductModel(
          id: 'produce-001',
          name: 'تفاح أحمر',
          storeName: 'خضار وفواكه',
          category: ProductCategories.produce,
          price: 2500,
          unit: 'كيلو',
          imageUrl: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=500',
        ),
        ProductModel(
          id: 'produce-002',
          name: 'موز بلدي',
          storeName: 'خضار وفواكه',
          category: ProductCategories.produce,
          price: 1500,
          unit: 'كيلو',
          imageUrl: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=500',
        ),
        ProductModel(
          id: 'produce-003',
          name: 'طماطم طازجة',
          storeName: 'خضار وفواكه',
          category: ProductCategories.produce,
          price: 1200,
          unit: 'كيلو',
          imageUrl: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=500',
        ),
        ProductModel(
          id: 'pharmacy-001',
          name: 'شامبو للعناية بالشعر',
          storeName: 'الصيدلية الآمنة',
          category: ProductCategories.pharmacy,
          price: 2200,
          unit: 'عبوة',
          imageUrl: 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?w=500',
        ),
        ProductModel(
          id: 'pharmacy-002',
          name: 'معجون أسنان وشفرات حلاقة',
          storeName: 'الصيدلية الآمنة',
          category: ProductCategories.pharmacy,
          price: 1500,
          unit: 'مجموعة',
          imageUrl: 'https://images.unsplash.com/photo-1559598467-f8b76c8155d0?w=500',
        ),
        ProductModel(
          id: 'pharmacy-003',
          name: 'مطهّر ومستلزمات إسعافات أولية',
          storeName: 'الصيدلية الآمنة',
          category: ProductCategories.pharmacy,
          price: 3000,
          unit: 'مجموعة',
          imageUrl: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500',
        ),
      ];

  Future<void> loadLocalData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _acceptedTerms = prefs.getBool(AppConstants.acceptedTermsKey) ?? false;
      _workStartHour = prefs.getInt(AppConstants.hoursStartKey) ?? 11;
      _workEndHour = prefs.getInt(AppConstants.hoursEndKey) ?? 22;
      _deliveryFee = prefs.getInt(AppConstants.deliveryFeeKey) ?? 500;
      final themeName = prefs.getString(AppConstants.themeKey) ?? 'dark';
      _themeMode = ThemeMode.values.firstWhere(
        (mode) => mode.name == themeName,
        orElse: () => ThemeMode.dark,
      );

      final userJson = prefs.getString(AppConstants.userStorageKey);
      if (userJson != null) {
        _user = UserModel.fromJson(Map<String, dynamic>.from(jsonDecode(userJson) as Map));
      }

      _restoreList<CartItemModel>(
        prefs.getString(AppConstants.cartStorageKey),
        _cart,
        CartItemModel.fromJson,
      );
      _restoreList<OrderModel>(
        prefs.getString(AppConstants.ordersStorageKey),
        _orders,
        OrderModel.fromJson,
      );
      _restoreList<DeliveryModel>(
        prefs.getString(AppConstants.couriersStorageKey),
        _couriers,
        DeliveryModel.fromJson,
      );

      final productsJson = prefs.getString(AppConstants.productsStorageKey);
      if (productsJson != null) {
        final decoded = jsonDecode(productsJson) as List<dynamic>;
        _products
          ..clear()
          ..addAll(decoded.map((item) => ProductModel.fromJson(Map<String, dynamic>.from(item as Map))));
      }
    } catch (_) {
      // عند تلف بيانات التخزين يبدأ التطبيق بالبيانات المحلية الافتراضية بدلاً من الانهيار.
    }
    _isReady = true;
    notifyListeners();
  }

  void _restoreList<T>(String? raw, List<T> destination, T Function(Map<String, dynamic>) parser) {
    if (raw == null) return;
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      destination
        ..clear()
        ..addAll(decoded.map((item) => parser(Map<String, dynamic>.from(item as Map))));
    } catch (_) {
      destination.clear();
    }
  }

  Future<void> _persistAll() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(AppConstants.cartStorageKey, jsonEncode(_cart.map((e) => e.toJson()).toList()));
      await prefs.setString(AppConstants.ordersStorageKey, jsonEncode(_orders.map((e) => e.toJson()).toList()));
      await prefs.setString(AppConstants.couriersStorageKey, jsonEncode(_couriers.map((e) => e.toJson()).toList()));
      await prefs.setString(AppConstants.productsStorageKey, jsonEncode(_products.map((e) => e.toJson()).toList()));
      if (_user != null) {
        await prefs.setString(AppConstants.userStorageKey, jsonEncode(_user!.toJson()));
      } else {
        await prefs.remove(AppConstants.userStorageKey);
      }
      await prefs.setBool(AppConstants.acceptedTermsKey, _acceptedTerms);
      await prefs.setString(AppConstants.themeKey, _themeMode.name);
      await prefs.setInt(AppConstants.hoursStartKey, _workStartHour);
      await prefs.setInt(AppConstants.hoursEndKey, _workEndHour);
      await prefs.setInt(AppConstants.deliveryFeeKey, _deliveryFee);
    } catch (_) {
      // فشل التخزين المحلي لا يجب أن يغلق الواجهة؛ لا تستخدم هذه النسخة لتخزين معاملات مالية.
    }
  }

  String _newId(String prefix) {
    final randomPart = Random.secure().nextInt(1 << 32).toRadixString(16);
    return '$prefix-${DateTime.now().microsecondsSinceEpoch}-$randomPart';
  }

  void acceptTerms() {
    _acceptedTerms = true;
    unawaited(_persistAll());
    notifyListeners();
  }

  void setThemeMode(ThemeMode mode) {
    _themeMode = mode;
    unawaited(_persistAll());
    notifyListeners();
  }

  void setUser({required String name, required String phone, required AddressModel address}) {
    final existing = _user;
    _user = UserModel(
      id: existing?.id ?? _newId('customer'),
      name: name.trim(),
      phone: Validators.toInternationalYemeniPhone(phone),
      addresses: [address],
    );
    unawaited(_persistAll());
    notifyListeners();
  }

  void clearUser() {
    _user = null;
    unawaited(_persistAll());
    notifyListeners();
  }

  void updateUser({String? name, String? phone}) {
    if (_user == null) return;
    _user = _user!.copyWith(
      name: name?.trim(),
      phone: phone == null ? null : Validators.toInternationalYemeniPhone(phone),
    );
    unawaited(_persistAll());
    notifyListeners();
  }

  void addOrUpdateAddress(AddressModel address) {
    if (_user == null) return;
    final addresses = [..._user!.addresses];
    final index = addresses.indexWhere((item) => item.id == address.id);
    if (index >= 0) {
      addresses[index] = address;
    } else {
      addresses.insert(0, address);
    }
    _user = _user!.copyWith(addresses: addresses);
    unawaited(_persistAll());
    notifyListeners();
  }

  void setDefaultAddress(String addressId) {
    if (_user == null) return;
    final selected = _user!.addresses.where((item) => item.id == addressId).toList();
    if (selected.isEmpty) return;
    final others = _user!.addresses.where((item) => item.id != addressId).toList();
    _user = _user!.copyWith(addresses: [selected.first, ...others]);
    unawaited(_persistAll());
    notifyListeners();
  }

  void addProductToCart(ProductModel product, {int quantity = 1}) {
    if (!product.isAvailable || quantity <= 0) return;
    final index = _cart.indexWhere((item) => item.productId == product.id);
    if (index >= 0) {
      final newQuantity = _cart[index].quantity + quantity;
      _cart[index] = _cart[index].copyWith(quantity: newQuantity);
    } else {
      _cart.add(CartItemModel(
        productId: product.id,
        name: product.name,
        unitPrice: product.price,
        quantity: quantity,
        unit: product.unit,
        imageUrl: product.imageUrl,
        storeName: product.storeName,
      ));
    }
    unawaited(_persistAll());
    notifyListeners();
  }

  void addCustomItem({required String name, required int price, required int quantity, required String notes}) {
    if (name.trim().isEmpty || price < 0 || quantity <= 0) return;
    final id = _newId('custom');
    _cart.add(CartItemModel(
      productId: id,
      name: notes.trim().isEmpty ? 'طلب خاص: ${name.trim()}' : 'طلب خاص: ${name.trim()} - ${notes.trim()}',
      unitPrice: price,
      quantity: quantity,
      unit: 'قطعة',
      storeName: 'طلب خاص',
    ));
    unawaited(_persistAll());
    notifyListeners();
  }

  void changeCartQuantity(String productId, int delta) {
    final index = _cart.indexWhere((item) => item.productId == productId);
    if (index < 0) return;
    final updatedQuantity = _cart[index].quantity + delta;
    if (updatedQuantity <= 0) {
      _cart.removeAt(index);
    } else {
      _cart[index] = _cart[index].copyWith(quantity: updatedQuantity);
    }
    unawaited(_persistAll());
    notifyListeners();
  }

  void removeCartItem(String productId) {
    _cart.removeWhere((item) => item.productId == productId);
    unawaited(_persistAll());
    notifyListeners();
  }

  void clearCart() {
    _cart.clear();
    unawaited(_persistAll());
    notifyListeners();
  }

  List<ProductModel> searchProducts(String query) {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty) return const [];
    return _products.where((product) {
      final haystack = '${product.name} ${product.storeName} ${product.description} ${ProductCategories.label(product.category)}'.toLowerCase();
      return haystack.contains(normalized);
    }).toList();
  }

  List<ProductModel> productsByCategory(String category) {
    return _products.where((item) => item.category == category).toList();
  }

  OrderModel placeOrder({required int deliveryFee, String notes = ''}) {
    if (_user == null) throw StateError('سجّل بيانات العميل أولاً.');
    if (_user!.defaultAddress == null) throw StateError('أضف عنوان توصيل أولاً.');
    if (_cart.isEmpty) throw StateError('السلة فارغة.');
    if (!isWorkingHours) throw StateError('التطبيق مغلق حالياً؛ لا يمكن إنشاء طلب جديد خارج أوقات الدوام.');

    for (final item in _cart) {
      final product = _products.where((product) => product.id == item.productId).firstOrNull;
      if (product != null && !product.isAvailable) {
        throw StateError('المنتج ${item.name} غير متوفر بالكمية المطلوبة.');
      }
      if (product != null && product.price != item.unitPrice) {
        throw StateError('تغير سعر ${item.name}. احذف المنتج من السلة وأضفه بالسعر الجديد.');
      }
    }

    final now = DateTime.now();
    final subtotal = cartSubtotal;
    final order = OrderModel(
      id: _newId('TE'),
      customerId: _user!.id,
      customerName: _user!.name,
      customerPhone: _user!.phone,
      address: _user!.defaultAddress!,
      items: List.unmodifiable(_cart),
      subtotal: subtotal,
      deliveryFee: deliveryFee,
      discount: 0,
      total: subtotal + deliveryFee,
      paymentMethod: 'cash_on_delivery',
      paymentStatus: PaymentStatuses.unpaid,
      status: OrderStatuses.pending,
      notes: notes,
      createdAt: now,
      updatedAt: now,
    );
    _orders.insert(0, order);
    _cart.clear();
    unawaited(_persistAll());
    notifyListeners();
    return order;
  }

  void updateOrderStatus(String orderId, String status) {
    final index = _orders.indexWhere((order) => order.id == orderId);
    if (index < 0 || !OrderStatuses.all.contains(status)) return;
    final oldOrder = _orders[index];
    if (!_canTransitionOrder(oldOrder.status, status)) return;
    _orders[index] = oldOrder.copyWith(status: status);

    final courierId = oldOrder.deliveryManId;
    if (courierId != null && (status == OrderStatuses.delivered || status == OrderStatuses.cancelled)) {
      final courierIndex = _couriers.indexWhere((courier) => courier.id == courierId);
      if (courierIndex >= 0) {
        final courier = _couriers[courierIndex];
        _couriers[courierIndex] = courier.copyWith(
          isAvailable: true,
          clearCurrentOrder: true,
          completedToday: status == OrderStatuses.delivered && oldOrder.status != OrderStatuses.delivered
              ? courier.completedToday + 1
              : courier.completedToday,
        );
      }
    }
    unawaited(_persistAll());
    notifyListeners();
  }


  bool _canTransitionOrder(String from, String to) {
    if (from == to) return true;
    final allowed = <String, Set<String>>{
      OrderStatuses.pending: {OrderStatuses.accepted, OrderStatuses.cancelled},
      OrderStatuses.accepted: {OrderStatuses.preparing, OrderStatuses.cancelled},
      OrderStatuses.preparing: {OrderStatuses.ready, OrderStatuses.cancelled},
      OrderStatuses.ready: {OrderStatuses.assigned, OrderStatuses.cancelled},
      OrderStatuses.assigned: {OrderStatuses.pickedUp, OrderStatuses.cancelled},
      OrderStatuses.pickedUp: {OrderStatuses.onTheWay, OrderStatuses.cancelled},
      OrderStatuses.onTheWay: {OrderStatuses.delivered, OrderStatuses.cancelled},
      OrderStatuses.delivered: <String>{},
      OrderStatuses.cancelled: <String>{},
    };
    return allowed[from]?.contains(to) ?? false;
  }

  void updatePaymentStatus(String orderId, String paymentStatus) {
    final index = _orders.indexWhere((order) => order.id == orderId);
    if (index < 0) return;
    _orders[index] = _orders[index].copyWith(paymentStatus: paymentStatus);
    unawaited(_persistAll());
    notifyListeners();
  }

  void addCourier({required String name, required String phone}) {
    final normalized = Validators.toInternationalYemeniPhone(phone);
    if (_couriers.any((courier) => courier.phone == normalized)) {
      throw StateError('رقم الهاتف مسجل لمندوب آخر.');
    }
    _couriers.add(DeliveryModel(id: _newId('delivery'), name: name.trim(), phone: normalized));
    unawaited(_persistAll());
    notifyListeners();
  }

  void updateCourier(DeliveryModel courier) {
    final index = _couriers.indexWhere((item) => item.id == courier.id);
    if (index < 0) return;
    if (courier.currentOrderId != null && !courier.isEnabled) {
      throw StateError('لا يمكن تعطيل مندوب لديه طلب نشط.');
    }
    final normalizedPhone = Validators.toInternationalYemeniPhone(courier.phone);
    if (_couriers.any((item) => item.id != courier.id && item.phone == normalizedPhone)) {
      throw StateError('رقم الهاتف مستخدم لمندوب آخر.');
    }
    _couriers[index] = courier.copyWith(phone: normalizedPhone);
    unawaited(_persistAll());
    notifyListeners();
  }

  void removeCourier(String courierId) {
    final courier = _couriers.where((item) => item.id == courierId).firstOrNull;
    if (courier == null || courier.currentOrderId != null) return;
    _couriers.removeWhere((item) => item.id == courierId);
    unawaited(_persistAll());
    notifyListeners();
  }

  DeliveryModel? courierByPhone(String phone) {
    final normalized = Validators.normalizeYemeniPhone(phone);
    for (final courier in _couriers) {
      if (Validators.normalizeYemeniPhone(courier.phone) == normalized && courier.isEnabled) return courier;
    }
    return null;
  }

  void setCourierAvailability(String courierId, bool isAvailable) {
    final index = _couriers.indexWhere((item) => item.id == courierId);
    if (index < 0) return;
    final courier = _couriers[index];
    if (courier.currentOrderId != null && isAvailable) return;
    _couriers[index] = courier.copyWith(isAvailable: isAvailable);
    unawaited(_persistAll());
    notifyListeners();
  }

  void assignOrderToCourier(String orderId, String courierId) {
    final orderIndex = _orders.indexWhere((item) => item.id == orderId);
    final courierIndex = _couriers.indexWhere((item) => item.id == courierId);
    if (orderIndex < 0 || courierIndex < 0) throw StateError('الطلب أو المندوب غير موجود.');
    final courier = _couriers[courierIndex];
    if (!courier.canReceiveOrders) throw StateError('هذا المندوب غير متاح حالياً.');

    final order = _orders[orderIndex];
    if (order.status != OrderStatuses.ready || order.deliveryManId != null) {
      throw StateError('يجب أن يكون الطلب جاهزاً وغير مسند إلى مندوب آخر.');
    }
    _orders[orderIndex] = order.copyWith(
      status: OrderStatuses.assigned,
      deliveryManId: courier.id,
    );
    _couriers[courierIndex] = courier.copyWith(
      isAvailable: false,
      currentOrderId: order.id,
    );
    unawaited(_persistAll());
    notifyListeners();
  }

  List<OrderModel> ordersForCourier(String courierId) {
    return _orders.where((order) => order.deliveryManId == courierId).toList();
  }

  void upsertProduct(ProductModel product) {
    final index = _products.indexWhere((item) => item.id == product.id);
    if (index < 0) {
      _products.add(product);
    } else {
      _products[index] = product;
    }
    unawaited(_persistAll());
    notifyListeners();
  }

  void removeProduct(String productId) {
    _products.removeWhere((item) => item.id == productId);
    _cart.removeWhere((item) => item.productId == productId);
    unawaited(_persistAll());
    notifyListeners();
  }

  void updateProductAvailability(String productId, bool isAvailable) {
    final index = _products.indexWhere((item) => item.id == productId);
    if (index < 0) return;
    _products[index] = _products[index].copyWith(isAvailable: isAvailable);
    unawaited(_persistAll());
    notifyListeners();
  }

  void updateBusinessSettings({required int startHour, required int endHour, required int deliveryFee}) {
    if (startHour < 0 || startHour > 23 || endHour < 1 || endHour > 24 || deliveryFee < 0) {
      throw ArgumentError('تأكد من صحة أوقات الدوام ورسوم التوصيل.');
    }
    _workStartHour = startHour;
    _workEndHour = endHour;
    _deliveryFee = deliveryFee;
    unawaited(_persistAll());
    notifyListeners();
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
