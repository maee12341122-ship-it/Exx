import 'package:flutter/material.dart';

class AppConstants {
  static const String appName = 'تعز إكسبرس';
  static const String appEnglishName = 'Taiz Express';
  static const Color gold = Color(0xFFFFC107);
  static const Color darkSurface = Color(0xFF1F1F1F);
  static const Color darkBackground = Color(0xFF121212);
  static const String ordersStorageKey = 'taiz_express_orders_v1';
  static const String cartStorageKey = 'taiz_express_cart_v1';
  static const String userStorageKey = 'taiz_express_user_v1';
  static const String couriersStorageKey = 'taiz_express_couriers_v1';
  static const String productsStorageKey = 'taiz_express_products_v1';
  static const String acceptedTermsKey = 'taiz_express_terms_accepted_v1';
  static const String themeKey = 'taiz_express_theme_v1';
  static const String hoursStartKey = 'taiz_express_hours_start_v1';
  static const String hoursEndKey = 'taiz_express_hours_end_v1';
  static const String deliveryFeeKey = 'taiz_express_delivery_fee_v1';
}

class ProductCategories {
  static const String restaurants = 'restaurants';
  static const String groceries = 'groceries';
  static const String produce = 'produce';
  static const String pharmacy = 'pharmacy';
  static const String custom = 'custom';

  static const List<String> all = [
    restaurants,
    groceries,
    produce,
    pharmacy,
    custom,
  ];

  static String label(String value) {
    switch (value) {
      case restaurants:
        return 'المطاعم';
      case groceries:
        return 'البقالات';
      case produce:
        return 'الخضار والفواكه';
      case pharmacy:
        return 'الصيدلية الآمنة';
      case custom:
        return 'طلبات أخرى';
      default:
        return 'أخرى';
    }
  }
}

class OrderStatuses {
  static const String pending = 'pending';
  static const String accepted = 'accepted';
  static const String preparing = 'preparing';
  static const String ready = 'ready';
  static const String assigned = 'assigned';
  static const String pickedUp = 'pickedUp';
  static const String onTheWay = 'onTheWay';
  static const String delivered = 'delivered';
  static const String cancelled = 'cancelled';

  static const List<String> all = [
    pending,
    accepted,
    preparing,
    ready,
    assigned,
    pickedUp,
    onTheWay,
    delivered,
    cancelled,
  ];

  static String label(String status) {
    switch (status) {
      case pending:
        return 'بانتظار المراجعة';
      case accepted:
        return 'تم قبول الطلب';
      case preparing:
        return 'قيد التجهيز';
      case ready:
        return 'جاهز للاستلام';
      case assigned:
        return 'تم تعيين مندوب';
      case pickedUp:
        return 'استلمه المندوب';
      case onTheWay:
        return 'في الطريق';
      case delivered:
        return 'تم التسليم';
      case cancelled:
        return 'ملغي';
      default:
        return status;
    }
  }
}

class PaymentStatuses {
  static const String unpaid = 'unpaid';
  static const String awaitingVerification = 'awaitingVerification';
  static const String paid = 'paid';
  static const String rejected = 'rejected';
  static const String refunded = 'refunded';
}
