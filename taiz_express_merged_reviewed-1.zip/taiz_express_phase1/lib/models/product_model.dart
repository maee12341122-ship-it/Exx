class ProductModel {
  final String id;
  final String name;
  final String storeName;
  final String category;
  final int price;
  final int? oldPrice;
  final String imageUrl;
  final String description;
  final String unit;
  final bool isAvailable;

  const ProductModel({
    required this.id,
    required this.name,
    required this.storeName,
    required this.category,
    required this.price,
    this.oldPrice,
    this.imageUrl = '',
    this.description = '',
    this.unit = 'حبة',
    this.isAvailable = true,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'storeName': storeName,
        'category': category,
        'price': price,
        'oldPrice': oldPrice,
        'imageUrl': imageUrl,
        'description': description,
        'unit': unit,
        'isAvailable': isAvailable,
      };

  factory ProductModel.fromJson(Map<String, dynamic> json) => ProductModel(
        id: json['id'] as String? ?? '',
        name: json['name'] as String? ?? '',
        storeName: json['storeName'] as String? ?? '',
        category: json['category'] as String? ?? 'groceries',
        price: (json['price'] as num?)?.toInt() ?? 0,
        oldPrice: (json['oldPrice'] as num?)?.toInt(),
        imageUrl: json['imageUrl'] as String? ?? '',
        description: json['description'] as String? ?? '',
        unit: json['unit'] as String? ?? 'حبة',
        isAvailable: json['isAvailable'] as bool? ?? false,
      );

  ProductModel copyWith({
    String? name,
    String? storeName,
    String? category,
    int? price,
    int? oldPrice,
    String? imageUrl,
    String? description,
    String? unit,
    bool? isAvailable,
  }) {
    return ProductModel(
      id: id,
      name: name ?? this.name,
      storeName: storeName ?? this.storeName,
      category: category ?? this.category,
      price: price ?? this.price,
      oldPrice: oldPrice ?? this.oldPrice,
      imageUrl: imageUrl ?? this.imageUrl,
      description: description ?? this.description,
      unit: unit ?? this.unit,
      isAvailable: isAvailable ?? this.isAvailable,
    );
  }
}
