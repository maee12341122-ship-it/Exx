class CartItemModel {
  final String productId;
  final String name;
  final int unitPrice;
  final int quantity;
  final String unit;
  final String imageUrl;
  final String storeName;

  const CartItemModel({
    required this.productId,
    required this.name,
    required this.unitPrice,
    required this.quantity,
    this.unit = 'حبة',
    this.imageUrl = '',
    this.storeName = '',
  });

  int get lineTotal => unitPrice * quantity;

  CartItemModel copyWith({int? quantity, int? unitPrice}) => CartItemModel(
        productId: productId,
        name: name,
        unitPrice: unitPrice ?? this.unitPrice,
        quantity: quantity ?? this.quantity,
        unit: unit,
        imageUrl: imageUrl,
        storeName: storeName,
      );

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'name': name,
        'unitPrice': unitPrice,
        'quantity': quantity,
        'unit': unit,
        'imageUrl': imageUrl,
        'storeName': storeName,
      };

  factory CartItemModel.fromJson(Map<String, dynamic> json) => CartItemModel(
        productId: json['productId'] as String? ?? '',
        name: json['name'] as String? ?? '',
        unitPrice: (json['unitPrice'] as num?)?.toInt() ?? 0,
        quantity: (json['quantity'] as num?)?.toInt() ?? 1,
        unit: json['unit'] as String? ?? 'حبة',
        imageUrl: json['imageUrl'] as String? ?? '',
        storeName: json['storeName'] as String? ?? '',
      );
}
