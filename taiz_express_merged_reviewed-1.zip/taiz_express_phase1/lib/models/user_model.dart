import 'address_model.dart';

class UserModel {
  final String id;
  final String name;
  final String phone;
  final List<AddressModel> addresses;

  const UserModel({
    required this.id,
    required this.name,
    required this.phone,
    this.addresses = const [],
  });

  AddressModel? get defaultAddress => addresses.isEmpty ? null : addresses.first;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'phone': phone,
        'addresses': addresses.map((address) => address.toJson()).toList(),
      };

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
        name: json['name'] as String? ?? '',
        phone: json['phone'] as String? ?? '',
        addresses: (json['addresses'] as List<dynamic>? ?? [])
            .whereType<Map<String, dynamic>>()
            .map(AddressModel.fromJson)
            .toList(),
      );

  UserModel copyWith({String? name, String? phone, List<AddressModel>? addresses}) {
    return UserModel(
      id: id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      addresses: addresses ?? this.addresses,
    );
  }
}
